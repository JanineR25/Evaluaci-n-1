from flask import Flask, request, jsonify
import sqlite3
import jwt
import datetime
from functools import wraps

app = Flask(__name__)
app.config['SECRET_KEY'] = "jalen2519" 
app.config['DATABASE'] = "database.db"

def get_db():
    conn = sqlite3.connect(app.config['DATABASE'])
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            status TEXT DEFAULT 'active',
            role_id INTEGER,
            FOREIGN KEY (role_id) REFERENCES roles(id)
        )
    """)
    
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS roles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            description TEXT
        )
    """)
    
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS permissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            description TEXT
        )
    """)
    
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS role_permissions (
            role_id INTEGER NOT NULL,
            permission_id INTEGER NOT NULL,
            PRIMARY KEY (role_id, permission_id),
            FOREIGN KEY (role_id) REFERENCES roles(id),
            FOREIGN KEY (permission_id) REFERENCES permissions(id)
        )
    """)
    
    
    roles = [
        (1, 'admin', 'Administrador con todos los permisos'),
        (2, 'editor', 'Puede editar contenido'),
        (3, 'viewer', 'Solo puede ver contenido')
    ]
    cursor.executemany(
        "INSERT OR IGNORE INTO roles (id, name, description) VALUES (?, ?, ?)", 
        roles
    )
    
    
    permissions = [
        (1, 'manage_users', 'Crear, editar y eliminar usuarios'),
        (2, 'edit_content', 'Modificar cualquier contenido'),
        (3, 'view_content', 'Ver contenido')
    ]
    cursor.executemany(
        "INSERT OR IGNORE INTO permissions (id, name, description) VALUES (?, ?, ?)", 
        permissions
    )
    
    
    role_permissions = [
        (1, 1), (1, 2), (1, 3), 
        (2, 2), (2, 3),          
        (3, 3)                    
    ]
    cursor.executemany(
        "INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (?, ?)", 
        role_permissions
    )
    
    
    users = [
        (1, 'admin', 'admin123', 'admin@example.com', 1),
        (2, 'editor1', 'editor123', 'editor1@example.com', 2),
        (3, 'viewer1', 'viewer123', 'viewer1@example.com', 3)
    ]
    cursor.executemany(
        """INSERT OR IGNORE INTO users 
           (id, username, password, email, role_id) 
           VALUES (?, ?, ?, ?, ?)""", 
        users
    )
    
    conn.commit()
    conn.close()


def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'message': 'Token requerido', 'status': 'error'}), 401
        
        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
            request.current_user = data
        except jwt.ExpiredSignatureError:
            return jsonify({'message': 'Token expirado', 'status': 'error'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'message': 'Token inválido', 'status': 'error'}), 401
        
        return f(*args, **kwargs)
    return decorated


def permission_required(permission_name):
    def decorator(f):
        @wraps(f)
        @token_required
        def wrapper(*args, **kwargs):
            conn = get_db()
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT 1 FROM role_permissions rp
                JOIN permissions p ON rp.permission_id = p.id
                WHERE rp.role_id = ? AND p.name = ?
            """, (request.current_user['role_id'], permission_name))
            
            has_permission = cursor.fetchone()
            conn.close()
            
            if not has_permission:
                return jsonify({'message': 'No tienes permiso para esta acción', 'status': 'error'}), 403
                
            return f(*args, **kwargs)
        return wrapper
    return decorator


@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    
    if not username or not password:
        return jsonify({'message': 'Usuario y contraseña requeridos', 'status': 'error'}), 400
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, username, role_id FROM users 
        WHERE username = ? AND password = ? AND status = 'active'
    """, (username, password))
    user = cursor.fetchone()
    conn.close()
    
    if not user:
        return jsonify({'message': 'Credenciales inválidas', 'status': 'error'}), 401
    
    token = jwt.encode({
        'user_id': user['id'],
        'username': user['username'],
        'role_id': user['role_id'],
        'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1)
    }, app.config['SECRET_KEY'], algorithm='HS256')
    
    return jsonify({
        'message': 'Login exitoso',
        'status': 'success',
        'token': token,
        'user': {
            'id': user['id'],
            'username': user['username'],
            'role_id': user['role_id']
        }
    })


@app.route('/users', methods=['POST'])
@permission_required('manage_users')
def create_user():
    data = request.get_json()
    required_fields = ['username', 'password', 'email', 'role_id']
    
    if not all(field in data for field in required_fields):
        return jsonify({'message': 'Faltan campos requeridos', 'status': 'error'}), 400
    
    conn = get_db()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            INSERT INTO users (username, password, email, role_id)
            VALUES (?, ?, ?, ?)
        """, (data['username'], data['password'], data['email'], data['role_id']))
        
        user_id = cursor.lastrowid
        conn.commit()
        
        cursor.execute("SELECT id, username, email, role_id FROM users WHERE id = ?", (user_id,))
        user = cursor.fetchone()
        
        return jsonify({
            'message': 'Usuario creado exitosamente',
            'status': 'success',
            'user': dict(user)
        }), 201
    except sqlite3.IntegrityError as e:
        conn.rollback()
        return jsonify({'message': 'Error al crear usuario: ' + str(e), 'status': 'error'}), 400
    finally:
        conn.close()

@app.route('/users', methods=['GET'])
@permission_required('manage_users')
def get_users():
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT u.id, u.username, u.email, u.status, r.name as role_name 
        FROM users u
        LEFT JOIN roles r ON u.role_id = r.id
    """)
    
    users = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return jsonify({
        'message': 'Lista de usuarios',
        'status': 'success',
        'users': users
    })

@app.route('/users/<int:user_id>', methods=['GET'])
@permission_required('manage_users')
def get_user(user_id):
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT u.id, u.username, u.email, u.status, r.name as role_name 
        FROM users u
        LEFT JOIN roles r ON u.role_id = r.id
        WHERE u.id = ?
    """, (user_id,))
    
    user = cursor.fetchone()
    conn.close()
    
    if not user:
        return jsonify({'message': 'Usuario no encontrado', 'status': 'error'}), 404
    
    return jsonify({
        'message': 'Usuario encontrado',
        'status': 'success',
        'user': dict(user)
    })

@app.route('/users/<int:user_id>', methods=['PUT'])
@permission_required('manage_users')
def update_user(user_id):
    data = request.get_json()
    
    conn = get_db()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            UPDATE users 
            SET username = COALESCE(?, username),
                email = COALESCE(?, email),
                password = COALESCE(?, password),
                role_id = COALESCE(?, role_id),
                status = COALESCE(?, status)
            WHERE id = ?
        """, (
            data.get('username'),
            data.get('email'),
            data.get('password'),
            data.get('role_id'),
            data.get('status'),
            user_id
        ))
        
        if cursor.rowcount == 0:
            conn.rollback()
            return jsonify({'message': 'Usuario no encontrado', 'status': 'error'}), 404
        
        conn.commit()
        
        cursor.execute("SELECT id, username, email, role_id, status FROM users WHERE id = ?", (user_id,))
        user = cursor.fetchone()
        
        return jsonify({
            'message': 'Usuario actualizado exitosamente',
            'status': 'success',
            'user': dict(user)
        })
    except sqlite3.IntegrityError as e:
        conn.rollback()
        return jsonify({'message': 'Error al actualizar usuario: ' + str(e), 'status': 'error'}), 400
    finally:
        conn.close()

@app.route('/users/<int:user_id>', methods=['DELETE'])
@permission_required('manage_users')
def delete_user(user_id):
    conn = get_db()
    cursor = conn.cursor()
    
    try:
        cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
        
        if cursor.rowcount == 0:
            conn.rollback()
            return jsonify({'message': 'Usuario no encontrado', 'status': 'error'}), 404
        
        conn.commit()
        return jsonify({
            'message': 'Usuario eliminado exitosamente',
            'status': 'success'
        })
    except sqlite3.Error as e:
        conn.rollback()
        return jsonify({'message': 'Error al eliminar usuario: ' + str(e), 'status': 'error'}), 400
    finally:
        conn.close()


@app.route('/roles', methods=['POST'])
@permission_required('manage_users')
def create_role():
    data = request.get_json()
    
    if 'name' not in data:
        return jsonify({'message': 'Nombre del rol es requerido', 'status': 'error'}), 400
    
    conn = get_db()
    cursor = conn.cursor()
    
    try:
        cursor.execute (
            "INSERT INTO roles (name, description) VALUES (?, ?)", 
            (data['name'], data.get('description', '')))
        
        role_id = cursor.lastrowid
        conn.commit()
        
        cursor.execute("SELECT id, name, description FROM roles WHERE id = ?", (role_id,))
        role = cursor.fetchone()
        
        return jsonify({
            'message': 'Rol creado exitosamente',
            'status': 'success',
            'role': dict(role)
        }), 201
    except sqlite3.IntegrityError as e:
        conn.rollback()
        return jsonify({'message': 'Error al crear rol: ' + str(e), 'status': 'error'}), 400
    finally:
        conn.close()

@app.route('/roles', methods=['GET'])
@permission_required('manage_users')
def get_roles():
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute("SELECT id, name, description FROM roles")
    roles = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return jsonify({
        'message': 'Lista de roles',
        'status': 'success',
        'roles': roles
    })

@app.route('/roles/<int:role_id>', methods=['PUT'])
@permission_required('manage_users')
def update_role(role_id):
    data = request.get_json()
    
    if 'name' not in data:
        return jsonify({'message': 'Nombre del rol es requerido', 'status': 'error'}), 400
    
    conn = get_db()
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "UPDATE roles SET name = ?, description = ? WHERE id = ?", 
            (data['name'], data.get('description', ''), role_id))
        
        if cursor.rowcount == 0:
            conn.rollback()
            return jsonify({'message': 'Rol no encontrado', 'status': 'error'}), 404
        
        conn.commit()
        
        cursor.execute("SELECT id, name, description FROM roles WHERE id = ?", (role_id,))
        role = cursor.fetchone()
        
        return jsonify({
            'message': 'Rol actualizado exitosamente',
            'status': 'success',
            'role': dict(role)
        })
    except sqlite3.IntegrityError as e:
        conn.rollback()
        return jsonify({'message': 'Error al actualizar rol: ' + str(e), 'status': 'error'}), 400
    finally:
        conn.close()

@app.route('/roles/<int:role_id>', methods=['DELETE'])
@permission_required('manage_users')
def delete_role(role_id):
    conn = get_db()
    cursor = conn.cursor()
    
    try:
        
        cursor.execute("SELECT 1 FROM users WHERE role_id = ? LIMIT 1", (role_id,))
        if cursor.fetchone():
            return jsonify({
                'message': 'No se puede eliminar el rol porque hay usuarios asignados',
                'status': 'error'
            }), 400
        
        cursor.execute("DELETE FROM roles WHERE id = ?", (role_id,))
        
        if cursor.rowcount == 0:
            conn.rollback()
            return jsonify({'message': 'Rol no encontrado', 'status': 'error'}), 404
        
        conn.commit()
        return jsonify({
            'message': 'Rol eliminado exitosamente',
            'status': 'success'
        })
    except sqlite3.Error as e:
        conn.rollback()
        return jsonify({'message': 'Error al eliminar rol: ' + str(e), 'status': 'error'}), 400
    finally:
        conn.close()


@app.route('/permissions', methods=['POST'])
@permission_required('manage_users')
def create_permission():
    data = request.get_json()
    
    if 'name' not in data:
        return jsonify({'message': 'Nombre del permiso es requerido', 'status': 'error'}), 400
    
    conn = get_db()
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "INSERT INTO permissions (name, description) VALUES (?, ?)", 
            (data['name'], data.get('description', '')))
        
        permission_id = cursor.lastrowid
        conn.commit()
        
        cursor.execute("SELECT id, name, description FROM permissions WHERE id = ?", (permission_id,))
        permission = cursor.fetchone()
        
        return jsonify({
            'message': 'Permiso creado exitosamente',
            'status': 'success',
            'permission': dict(permission)
        }), 201
    except sqlite3.IntegrityError as e:
        conn.rollback()
        return jsonify({'message': 'Error al crear permiso: ' + str(e), 'status': 'error'}), 400
    finally:
        conn.close()

@app.route('/permissions', methods=['GET'])
@permission_required('manage_users')
def get_permissions():
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute("SELECT id, name, description FROM permissions")
    permissions = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return jsonify({
        'message': 'Lista de permisos',
        'status': 'success',
        'permissions': permissions
    })

@app.route('/permissions/<int:permission_id>', methods=['PUT'])
@permission_required('manage_users')
def update_permission(permission_id):
    data = request.get_json()
    
    if 'name' not in data:
        return jsonify({'message': 'Nombre del permiso es requerido', 'status': 'error'}), 400
    
    conn = get_db()
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "UPDATE permissions SET name = ?, description = ? WHERE id = ?", 
            (data['name'], data.get('description', ''), permission_id))
        
        if cursor.rowcount == 0:
            conn.rollback()
            return jsonify({'message': 'Permiso no encontrado', 'status': 'error'}), 404
        
        conn.commit()
        
        cursor.execute("SELECT id, name, description FROM permissions WHERE id = ?", (permission_id,))
        permission = cursor.fetchone()
        
        return jsonify({
            'message': 'Permiso actualizado exitosamente',
            'status': 'success',
            'permission': dict(permission)
        })
    except sqlite3.IntegrityError as e:
        conn.rollback()
        return jsonify({'message': 'Error al actualizar permiso: ' + str(e), 'status': 'error'}), 400
    finally:
        conn.close()

@app.route('/permissions/<int:permission_id>', methods=['DELETE'])
@permission_required('manage_users')
def delete_permission(permission_id):
    conn = get_db()
    cursor = conn.cursor()
    
    try:
        
        cursor.execute("SELECT 1 FROM role_permissions WHERE permission_id = ? LIMIT 1", (permission_id,))
        if cursor.fetchone():
            return jsonify({
                'message': 'No se puede eliminar el permiso porque está asignado a roles',
                'status': 'error'
            }), 400
        
        cursor.execute("DELETE FROM permissions WHERE id = ?", (permission_id,))
        
        if cursor.rowcount == 0:
            conn.rollback()
            return jsonify({'message': 'Permiso no encontrado', 'status': 'error'}), 404
        
        conn.commit()
        return jsonify({
            'message': 'Permiso eliminado exitosamente',
            'status': 'success'
        })
    except sqlite3.Error as e:
        conn.rollback()
        return jsonify({'message': 'Error al eliminar permiso: ' + str(e), 'status': 'error'}), 400
    finally:
        conn.close()


@app.route('/roles/<int:role_id>/permissions', methods=['POST'])
@permission_required('manage_users')
def assign_permission(role_id):
    data = request.get_json()
    
    if 'permission_id' not in data:
        return jsonify({'message': 'ID del permiso es requerido', 'status': 'error'}), 400
    
    conn = get_db()
    cursor = conn.cursor()
    
    try:
        
        cursor.execute("SELECT 1 FROM roles WHERE id = ?", (role_id,))
        if not cursor.fetchone():
            return jsonify({'message': 'Rol no encontrado', 'status': 'error'}), 404
        
        
        cursor.execute("SELECT 1 FROM permissions WHERE id = ?", (data['permission_id'],))
        if not cursor.fetchone():
            return jsonify({'message': 'Permiso no encontrado', 'status': 'error'}), 404
        
        
        cursor.execute("""
            INSERT OR IGNORE INTO role_permissions (role_id, permission_id)
            VALUES (?, ?)
        """, (role_id, data['permission_id']))
        
        conn.commit()
        return jsonify({
            'message': 'Permiso asignado al rol exitosamente',
            'status': 'success'
        })
    except sqlite3.IntegrityError as e:
        conn.rollback()
        return jsonify({'message': 'Error al asignar permiso: ' + str(e), 'status': 'error'}), 400
    finally:
        conn.close()

@app.route('/roles/<int:role_id>/permissions', methods=['GET'])
@permission_required('manage_users')
def get_role_permissions(role_id):
    conn = get_db()
    cursor = conn.cursor()
    
    
    cursor.execute("SELECT 1 FROM roles WHERE id = ?", (role_id,))
    if not cursor.fetchone():
        return jsonify({'message': 'Rol no encontrado', 'status': 'error'}), 404
    
    
    cursor.execute("""
        SELECT p.id, p.name, p.description 
        FROM permissions p
        JOIN role_permissions rp ON p.id = rp.permission_id
        WHERE rp.role_id = ?
    """, (role_id,))
    
    permissions = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return jsonify({
        'message': f'Permisos del rol {role_id}',
        'status': 'success',
        'permissions': permissions
    })

@app.route('/roles/<int:role_id>/permissions/<int:permission_id>', methods=['DELETE'])
@permission_required('manage_users')
def remove_permission(role_id, permission_id):
    conn = get_db()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            DELETE FROM role_permissions 
            WHERE role_id = ? AND permission_id = ?
        """, (role_id, permission_id))
        
        if cursor.rowcount == 0:
            conn.rollback()
            return jsonify({'message': 'Asignación no encontrada', 'status': 'error'}), 404
        
        conn.commit()
        return jsonify({
            'message': 'Permiso removido del rol exitosamente',
            'status': 'success'
        })
    except sqlite3.Error as e:
        conn.rollback()
        return jsonify({'message': 'Error al remover permiso: ' + str(e), 'status': 'error'}), 400
    finally:
        conn.close()


@app.route('/protected', methods=['GET'])
@token_required
def protected_route():
    return jsonify({
        'message': f'Bienvenido {request.current_user["username"]}! Esta es una ruta protegida',
        'status': 'success',
        'user': request.current_user
    })


@app.route('/public', methods=['GET'])
def public_route():
    return jsonify({
        'message': 'Esta es una ruta pública',
        'status': 'success'
    })

if __name__ == '__main__':
    init_db()
    app.run(debug=True)