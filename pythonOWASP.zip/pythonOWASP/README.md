## Version Python
 3.13

## Dependencies to install 

see requirements.txt

## steps to run
## 1. Create enviroment
python -m "name enviroment"
## 2. Activate venv
source venv/bin/activate (on Linux/Unix)
## 3. Install dependencies
pip install -r requirements.txt
## 4. python "file name"
example:
python app_vulnerate.py

